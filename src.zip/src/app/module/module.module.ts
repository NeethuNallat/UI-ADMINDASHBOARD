import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModuleRoutingModule } from './module-routing.module';
import { HeaderComponent } from './layout/commonlayout/header/header/header.component';
import { FooterComponent } from './layout/commonlayout/footer/footer/footer.component';
import { DashboardComponent } from './layout/pages/dashboard/dashboard.component';
import { LeftsidebarComponent } from './layout/pages/leftsidebar/leftsidebar.component';
import { RightsidebarComponent } from './layout/pages/rightsidebar/rightsidebar.component';
import { CollectioncardComponent } from './layout/pages/collectioncard/collectioncard.component';
import { GraphsectionComponent } from './layout/pages/graphsection/graphsection.component';
import { SalessectionComponent } from './layout/pages/salessection/salessection.component';
import { OrdersectionComponent } from './layout/pages/ordersection/ordersection.component';


@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    DashboardComponent
   
  ],
  imports: [
    CommonModule,
    ModuleRoutingModule
  ]
})
export class ModuleModule { }
