import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ordersection',
  templateUrl: './ordersection.component.html',
  styleUrls: ['./ordersection.component.scss']
})
export class OrdersectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
