import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salessection',
  templateUrl: './salessection.component.html',
  styleUrls: ['./salessection.component.scss']
})
export class SalessectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
