import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-graphsection',
  templateUrl: './graphsection.component.html',
  styleUrls: ['./graphsection.component.scss']
})
export class GraphsectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
