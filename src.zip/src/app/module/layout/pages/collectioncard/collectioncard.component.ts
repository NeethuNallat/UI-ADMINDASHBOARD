import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collectioncard',
  templateUrl: './collectioncard.component.html',
  styleUrls: ['./collectioncard.component.scss']
})
export class CollectioncardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
